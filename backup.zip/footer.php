<footer class="page-footer orange" style="position: relative;margin-top: 228px; /* negative value of footer height */;clear: both;">
    
    <div class="footer-copyright">
      <div class="container">
      Made by <span class="orange-text text-lighten-3"><a href="#" style="color: white">Tim Kuliahku</a> - MBD E</span> 
      </div>
    </div>
  </footer>